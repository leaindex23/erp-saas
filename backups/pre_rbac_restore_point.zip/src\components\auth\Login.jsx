import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setUser, setLoading, setError } from '../../features/authSlice';
import { supabase } from '../../lib/supabaseClient';
import { TrendingUp, LogIn } from 'lucide-react';

export default function Login() {
  const dispatch = useDispatch();
  const { loading, error } = useSelector(state => state.auth);

  const handleGoogleLogin = async () => {
    dispatch(setLoading(true));
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: window.location.origin,
        }
      });
      if (error) throw error;
    } catch (e) {
      dispatch(setError(e.message));
    }
  };

  // Temporarily added a "Bypass Login" for development ease if Supabase is not configured yet
  const bypassLogin = () => {
    dispatch(setUser({ email: 'admin@financesaas.com', user_metadata: { full_name: 'Admin User' } }));
  };

  return (
    <div className="login-screen animate-fade-in">
      <div className="login-card">
        <div className="login-brand">
          <div className="brand-logo">
            <TrendingUp size={32} color="var(--primary)" strokeWidth={3} />
          </div>
          <h1>FinanceSAAS</h1>
          <p>Potencia el control financiero de tu holding</p>
        </div>
        
        <div className="login-actions">
          <button className="btn btn-primary btn-google" onClick={handleGoogleLogin} disabled={loading}>
            <LogIn size={18} />
            {loading ? 'Cargando...' : 'Entrar con Google'}
          </button>
          
          <button className="btn btn-primary" onClick={bypassLogin} style={{ marginTop: '1.5rem', background: 'rgba(99,102,241,0.1)', border: '1px solid var(--primary)', color: 'var(--primary)', width: '100%', height: '45px', fontWeight: 700 }}>
            🚀 ENTRAR EN MODO PRUEBA (Sin Supabase)
          </button>
          
          {error && <div className="error-message">{error}</div>}
        </div>
        
        <div className="login-footer">
          &copy; 2026 FinanceSAAS Platform. Todos los derechos reservados.
        </div>
      </div>
    </div>
  );
}
