import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  user: null,
  role: null, // ADMIN, MANAGER, etc.
  scopes: [], // GLOBAL, COMPANY, CAJA
  loading: false,
  error: null,
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.user = action.payload;
      state.loading = false;
    },
    setRole: (state, action) => {
      state.role = action.payload.role;
      state.scopes = action.payload.scopes;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
      state.loading = false;
    },
    logout: (state) => {
      state.user = null;
      state.role = null;
      state.scopes = [];
    }
  },
});

export const { setUser, setRole, setLoading, setError, logout } = authSlice.actions;
export default authSlice.reducer;
